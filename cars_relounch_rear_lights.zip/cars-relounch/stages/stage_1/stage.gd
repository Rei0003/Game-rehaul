extends Node3D

# Gives every mesh in the stage a collision shape that matches it exactly,
# so re-exporting the .glb from Blender never needs collision set up again.
func _ready() -> void:
	add_collision(self)

func add_collision(node: Node) -> void:
	for child in node.get_children():
		if child is MeshInstance3D:
			child.create_trimesh_collision()
		add_collision(child)
