extends Camera3D

# Game camera. Press C to cycle through five views: three chase views
# (close, normal, far), then hood, then bumper.
#
# The camera reacts to the car so that speed is something you feel: the view
# widens and the camera drops at speed, it falls back when you accelerate and
# closes up when you brake, it swings and tilts in corners, and it shakes at
# top speed, in drifts and on hard landings.

@export var target: Node3D

@export_group("Views")
@export var chase_distances: Array[float] = [3.8, 4.4, 6.0]   # close, normal, far (metres behind the car's centre)
@export var chase_heights: Array[float] = [1.15, 1.5, 2.2]    # metres above the car's centre
@export var car_half_length: float = 2.35                    # centre to rear bumper, so the camera never crowds it
@export var hood_position: Vector3 = Vector3(0.0, 0.68, 1.05)
@export var bumper_position: Vector3 = Vector3(0.0, 0.02, 2.42)
@export var start_view: int = 1                               # 0-2 = chase views, 3 = hood, 4 = bumper

@export_group("Sense of speed")
@export var chase_fov: float = 70.0
@export var chase_fov_at_top_speed: float = 90.0
@export var onboard_fov: float = 74.0
@export var onboard_fov_at_top_speed: float = 96.0
@export_range(0.0, 1.0) var keep_car_size: float = 0.85  # moves the camera in as the view widens, so the car doesn't shrink
@export var drop_at_speed: float = 0.22     # share of its height the camera drops by at top speed
@export var look_ahead_at_speed: float = 1.0  # metres ahead of the car the camera aims at top speed
@export var speed_shake: float = 0.02       # metres, at top speed
@export var drift_shake: float = 0.04       # metres
@export var drift_fov_boost: float = 4.0    # degrees
@export var impact_shake: float = 0.25      # metres, for landings and crashes
@export_range(0.0, 1.0) var motion_blur: float = 0.5   # speed blur at the edges of the screen (0 = off)
@export var blur_start: float = 0.35        # share of top speed where the blur begins

@export_group("Reactions")
@export var follow_speed: float = 5.0
@export var turn_swing: float = 3.0         # lower = the camera swings wider in corners
@export var accel_pull: float = 0.06        # metres the camera falls back per m/s^2 of acceleration
@export var max_pull: float = 0.7           # metres
@export var turn_tilt: float = 0.12         # degrees of tilt per m/s^2 of cornering
@export var look_into_turn: float = 0.5     # metres the aim moves towards the inside of a corner
@export var vertical_smoothing: float = 9.0 # lower = the car bobs more against the camera over bumps
@export var gear_shift_kick: float = 1.5    # degrees the view pinches in on a gear change

@export_group("Burnout view")
@export var burnout_distance: float = 3.2
@export var burnout_height: float = 0.7
@export var burnout_blend_in: float = 1.2   # how fast it swings round (1 / seconds)
@export var burnout_blend_out: float = 1.8  # how fast it swings back
@export var burnout_fov: float = 55.0

const VIEW_NAMES = ["Chase close", "Chase", "Chase far", "Hood", "Bumper"]

var view: int = 1
var cam_dir: Vector3 = Vector3.BACK      # which way the chase camera is facing (flat)
var offset: Vector3 = Vector3.ZERO       # chase camera position relative to the car
var cur_distance: float = 4.4
var cur_height: float = 1.5
var pull: float = 0.0                    # metres back (+) or forward (-) from acceleration
var smooth_y: float = 0.0
var burnout_blend: float = 0.0
var trauma: float = 0.0                  # 0 to 1, set by impacts, fades out
var fov_kick: float = 0.0
var last_gear: int = 1
var last_velocity: Vector3 = Vector3.ZERO
var shake_noise := FastNoiseLite.new()
var shake_time: float = 0.0
var blur_material: ShaderMaterial


func _ready() -> void:
	view = clampi(start_view, 0, VIEW_NAMES.size() - 1)
	shake_noise.frequency = 1.0
	setup_blur()
	reset_view.call_deferred()


# The speed blur is a full-screen rectangle drawn over the 3D picture with the
# blur shader on it. It sits on its own layer below the HUD (layer 0), so a HUD
# on a higher layer stays sharp.
func setup_blur() -> void:
	blur_material = ShaderMaterial.new()
	blur_material.shader = load("res://speed_blur.gdshader")
	var layer = CanvasLayer.new()
	layer.name = "SpeedBlur"
	layer.layer = 0
	var rect = ColorRect.new()
	rect.material = blur_material
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(rect)
	add_child(layer)


# Tells the blur how strong to be and where on screen the car and its heading are.
func update_blur(body: RigidBody3D, speed: float, top_speed: float, blend_out: float) -> void:
	var amount = smoothstep(blur_start, 1.0, speed / top_speed) * motion_blur * (1.0 - blend_out)
	blur_material.set_shader_parameter("strength", amount)
	if amount <= 0.0:
		return
	var screen = get_viewport().get_visible_rect().size
	var direction = body.linear_velocity.normalized()
	var ahead = target.global_position + direction * 80.0
	var heading_point = Vector2(0.5, 0.5)
	if not is_position_behind(ahead):
		heading_point = unproject_position(ahead) / screen
	var sharp_point = heading_point
	var sharp_radius = 0.12
	if not is_onboard():
		sharp_point = unproject_position(target.global_position) / screen
		sharp_radius = 0.3
	blur_material.set_shader_parameter("heading_point", heading_point)
	blur_material.set_shader_parameter("sharp_point", sharp_point)
	blur_material.set_shader_parameter("sharp_radius", sharp_radius)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_view"):
		next_view()


func next_view() -> void:
	var was_onboard = is_onboard()
	view = (view + 1) % VIEW_NAMES.size()
	if was_onboard and not is_onboard():
		reset_view()   # coming back outside: start straight behind the car


func is_onboard() -> bool:
	return view >= 3


# Puts the chase camera straight behind the car, with nothing left over from before.
func reset_view() -> void:
	if target == null:
		return
	var heading = target.global_transform.basis.z
	heading.y = 0.0
	cam_dir = heading.normalized()
	offset = Vector3.ZERO
	pull = 0.0
	smooth_y = target.global_position.y
	var chase = min(view, 2)
	cur_distance = chase_distances[chase]
	cur_height = chase_heights[chase]
	last_velocity = (target as RigidBody3D).linear_velocity


func _physics_process(delta: float) -> void:
	var body = target as RigidBody3D
	var heading = target.global_transform.basis.z
	heading.y = 0.0
	heading = heading.normalized()
	var vel = body.linear_velocity
	var flat_vel = Vector3(vel.x, 0.0, vel.z)
	var speed = flat_vel.length()
	var top_speed = body.max_speed_kmh / 3.6
	var speed_amount = pow(clamp(speed / top_speed, 0.0, 1.0), 1.3)
	var accel = body.local_accel   # x = sideways (left is +), z = forwards

	shake_time += delta

	# Hard knocks (a landing, a wall) shake the camera for a moment.
	var knock = (vel - last_velocity).length() / delta
	last_velocity = vel
	if knock > 30.0:
		trauma = max(trauma, clamp((knock - 30.0) / 60.0, 0.0, 1.0))
	trauma = move_toward(trauma, 0.0, 2.5 * delta)

	# A gear change pinches the view in for a moment.
	if body.gear > last_gear and last_gear >= 1:
		fov_kick = gear_shift_kick
	last_gear = body.gear
	fov_kick = move_toward(fov_kick, 0.0, 8.0 * delta)

	var shake_size = speed_shake * speed_amount * speed_amount + drift_shake * body.drift_intensity + impact_shake * trauma * trauma
	var shake = Vector3(shake_noise.get_noise_1d(shake_time * 30.0), shake_noise.get_noise_1d(shake_time * 30.0 + 50.0), 0.0) * shake_size
	var tilt = deg_to_rad(clamp(accel.x * turn_tilt, -3.0, 3.0))

	if is_onboard():
		update_onboard(body, speed_amount, accel, shake, tilt)
	else:
		update_chase(delta, body, heading, flat_vel, speed, speed_amount, accel, shake, tilt)


# Hood and bumper views: fixed to the car, looking forwards.
func update_onboard(body: RigidBody3D, speed_amount: float, accel: Vector3, shake: Vector3, tilt: float) -> void:
	var local_position = hood_position if view == 3 else bumper_position
	var shake_scale = 0.6 if view == 3 else 1.2
	global_transform = Transform3D(target.global_transform.basis * Basis(Vector3.UP, PI), target.to_global(local_position))
	rotate_object_local(Vector3.UP, body.steer_angle * 0.3)                          # glance into the corner
	rotate_object_local(Vector3.RIGHT, deg_to_rad(clamp(accel.z * 0.08, -1.5, 1.5)))  # tips back under power
	rotate_object_local(Vector3.BACK, tilt * 0.6)
	global_position += global_transform.basis * (shake * shake_scale)
	fov = lerp(onboard_fov, onboard_fov_at_top_speed, speed_amount) + drift_fov_boost * body.drift_intensity - fov_kick
	update_blur(body, body.linear_velocity.length(), body.max_speed_kmh / 3.6, 0.0)


# The three chase views.
func update_chase(delta: float, body: RigidBody3D, heading: Vector3, flat_vel: Vector3, speed: float, speed_amount: float, accel: Vector3, shake: Vector3, tilt: float) -> void:
	# Face somewhere between where the car points and where it is going, and
	# turn towards that gradually: this is what shows the car's side in a slide.
	var desired = heading
	if speed > 5.0 and flat_vel.normalized().dot(heading) > 0.0:
		desired = heading.slerp(flat_vel.normalized(), 0.7)
	cam_dir = cam_dir.slerp(desired, 1.0 - exp(-turn_swing * delta)).normalized()

	# Ease towards the chosen view's distance and height.
	var chase = min(view, 2)
	cur_distance = lerp(cur_distance, chase_distances[chase], 1.0 - exp(-6.0 * delta))
	cur_height = lerp(cur_height, chase_heights[chase], 1.0 - exp(-6.0 * delta))

	# Burnout view: swing round to the driven wheels.
	var blend_rate = burnout_blend_in if body.burnout else burnout_blend_out
	burnout_blend = move_toward(burnout_blend, 1.0 if body.burnout else 0.0, blend_rate * delta)
	var b = smoothstep(0.0, 1.0, burnout_blend)
	var axle_z = lerp(-1.35, 1.35, body.front_drive_ratio)
	var orbit_angle = deg_to_rad(lerp(55.0, 135.0, body.front_drive_ratio)) * b
	var orbit_dir = (-cam_dir).rotated(Vector3.UP, -orbit_angle)
	var focus = heading * axle_z * b

	# The view widens with speed. To stop the car shrinking on screen, the
	# camera also moves in a little as it widens.
	var view_angle = lerp(chase_fov, chase_fov_at_top_speed, speed_amount) + drift_fov_boost * body.drift_intensity - fov_kick
	var size_keep = tan(deg_to_rad(chase_fov) / 2.0) / tan(deg_to_rad(view_angle) / 2.0)
	# Only the gap behind the rear bumper shrinks, so the camera never ends up on top of the car.
	var gap = max(cur_distance - car_half_length, 0.5)
	var driving_distance = car_half_length + gap * lerp(1.0, size_keep, keep_car_size)
	var driving_height = cur_height * (1.0 - drop_at_speed * speed_amount)

	# Falls back under acceleration, closes up under braking.
	var wanted_pull = clamp(accel.z * accel_pull, -max_pull * 0.5, max_pull)
	pull = lerp(pull, wanted_pull, 1.0 - exp(-4.0 * delta))

	var orbit_distance = lerp(driving_distance + pull, burnout_distance, b) + sin(b * PI) * 1.5
	var wanted_offset = focus + orbit_dir * orbit_distance + Vector3.UP * lerp(driving_height, burnout_height, b)
	if offset == Vector3.ZERO:
		offset = wanted_offset
	offset = offset.lerp(wanted_offset, 1.0 - exp(-follow_speed * delta))

	# Follow the car's height a touch late, so it bobs against the camera over bumps.
	smooth_y = lerp(smooth_y, target.global_position.y, 1.0 - exp(-vertical_smoothing * delta))
	var car_pos = Vector3(target.global_position.x, smooth_y, target.global_position.z)

	# Aim a little ahead of the car at speed, and towards the inside of a corner.
	var side = Vector3.UP.cross(heading)   # the car's left
	var yaw_rate = body.angular_velocity.y
	# Aim low enough that the whole car, wheels included, stays in the picture.
	var aim_height = max(0.45 * (cur_height - 1.1), 0.0)
	var aim = car_pos + focus + Vector3.UP * lerp(aim_height, 0.1, b)
	aim += (heading * look_ahead_at_speed * speed_amount + side * clamp(yaw_rate * look_into_turn, -1.0, 1.0)) * (1.0 - b)

	global_position = car_pos + offset
	look_at(aim, Vector3.UP)
	rotate_object_local(Vector3.BACK, tilt * (1.0 - b))
	global_position += global_transform.basis * shake
	fov = lerp(view_angle, burnout_fov, b)
	update_blur(body, speed, body.max_speed_kmh / 3.6, b)
