extends RigidBody3D

# Arcade car handling, aimed at a Need for Speed Payback feel.
# One script drives every car: a car's own numbers are set on its scene.

@export_group("Engine")
@export var engine_force: float = 12000.0       # peak push from the engine (newtons)
@export var max_speed_kmh: float = 240.0        # top of the last gear
@export var gear_count: int = 5
@export var shift_time: float = 0.1             # power cut while changing gear (seconds)
@export var reverse_speed_kmh: float = 60.0
@export var air_drag: float = 1.2
@export var rolling_drag: float = 0.6           # slowdown with no throttle (m/s^2)
@export_range(0.0, 1.0) var front_drive_ratio: float = 1.0  # 0 = RWD, 1 = FWD, 0.4 = AWD

@export_group("Brakes")
@export var brake_force: float = 17000.0        # all four wheels, about 1.3 g
@export_range(0.0, 1.0) var brake_front_bias: float = 0.65
@export var handbrake_force: float = 6000.0     # rear wheels only

@export_group("Steering")
@export var max_steer_angle: float = 0.5        # radians, about 28 degrees
@export var steer_speed: float = 4.0            # how fast the wheels turn (radians per second)
@export var high_speed_steer: float = 0.35      # share of full lock left at 144 km/h
@export var top_speed_steer: float = 0.24       # share of full lock left at top speed
@export var counter_steer_assist: float = 0.8
@export var high_speed_steer_rate: float = 0.5  # steering turns this much slower at top speed
@export var high_speed_stability: float = 1.5   # calms the car's rotation at speed (not while drifting)

@export_group("Tyres")
@export var front_mu: float = 2.2               # sideways grip in g
@export var rear_mu: float = 2.4
@export var peak_slip_angle: float = 4.0        # front tyres: degrees of slide where grip peaks
@export var rear_peak_slip_angle: float = 2.5   # rear tyres: lower = the rear follows more tightly (stable)
@export var slide_ratio: float = 0.8            # grip left once a tyre is fully sliding
@export var grip: float = 0.8                   # low-speed stiffness (0 to 1)
@export_range(0.0, 1.0) var load_sensitivity: float = 0.5  # how much weight on a tyre changes its grip

@export_group("Suspension")
@export var spring_strength: float = 16000.0
@export var spring_damping: float = 3500.0
@export var rest_length: float = 0.7
@export var bump_stop_start: float = 0.32       # compression (m) where the bump stop begins
@export var bump_stop_strength: float = 150000.0
@export var downforce: float = 0.4              # pushes the car into the road at speed

@export_group("Drift")
@export var handbrake_grip: float = 0.2         # rear grip while the handbrake is held
@export var handbrake_kick: float = 1.8         # rotation added when a drift starts
@export var drift_grip_loss: float = 0.45       # rear grip lost during a drift
@export var max_drift_angle: float = 36.0       # degrees, with full steering into the drift
@export var neutral_drift_angle: float = 0.6    # share of that angle with the steering centred
@export var angle_limit_strength: float = 15.0
@export var drift_push: float = 7500.0          # keeps speed up while drifting on the throttle
@export var drift_power_yaw: float = 1.2        # how hard the throttle swings the rear out
@export var transition_kick: float = 1.4        # rotation added when flicking to the other side
@export var grip_fight: float = 0.2             # how much the rear grip shudders in a slide
@export var grip_fight_speed: float = 2.5
@export var grip_change_speed: float = 12.0

@export_group("Feel")
@export var yaw_inertia: float = 1600.0
@export var burnout_max_speed: float = 4.0      # m/s, a burnout only starts below this
@export var body_shake: float = 0.006           # body vibration on the limiter (metres)
@export var body_roll: float = 0.2              # visual lean in corners (degrees per m/s^2)
@export var body_pitch: float = 0.12            # visual squat and dive (degrees per m/s^2)
@export var air_levelling: float = 3.0          # how strongly the car levels itself in the air
@export var wall_friction: float = 0.02         # low = glances off walls instead of grinding
@export var wall_bounce: float = 0.3
@export var wall_spin_damping: float = 8.0      # stops a wall hit from whipping the car round

# State other scripts read (wheels, camera, and later the HUD and engine sound).
var steer_angle: float = 0.0
var throttle: float = 0.0
var drifting: bool = false
var drift_dir: float = 0.0          # +1 = drifting left, -1 = drifting right
var burnout: bool = false
var drift_intensity: float = 0.0    # 0 to 1
var launch_spin: float = 0.0        # 0 to 1, wheelspin off the line
var gear: int = 1                   # -1 = reverse
var rpm: float = 0.0                # 0 to 1, where 1 is the limiter
var on_limiter: bool = false
var grounded_wheels: int = 0
var brake_lights_on: bool = false   # read by the lights script

var rear_grip_factor: float = 1.0
var last_compression := {}
var wheel_load := {}
var shift_timer: float = 0.0
var reverse_timer: float = 0.0
var neutral_timer: float = 0.0
var counter_timer: float = 0.0
var feel_noise := FastNoiseLite.new()
var feel_time: float = 0.0
var body_rest: Transform3D
var last_velocity: Vector3 = Vector3.ZERO
var local_accel: Vector3 = Vector3.ZERO   # smoothed, in the car's own directions

@onready var wheels: Array[RayCast3D] = [$FL, $FR, $RL, $RR]


func _ready() -> void:
	linear_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	linear_damp = 0.05
	if yaw_inertia > 0.0:
		inertia = Vector3(2262.0, yaw_inertia, 420.0)
	var material = PhysicsMaterial.new()
	material.friction = wall_friction
	material.bounce = wall_bounce
	physics_material_override = material
	contact_monitor = true
	max_contacts_reported = 4
	feel_noise.frequency = 1.0
	body_rest = $Body.transform


# Visual only: the body leans in corners, squats and dives, and vibrates on the limiter.
func _process(_delta: float) -> void:
	var shake = max(drift_intensity, 1.0 if burnout else 0.0)
	var t = feel_time * 25.0
	var offset = Vector3(feel_noise.get_noise_1d(t), feel_noise.get_noise_1d(t + 100.0), 0.0) * body_shake * shake
	var roll = deg_to_rad(clamp(local_accel.x * body_roll, -4.5, 4.5))
	var pitch = deg_to_rad(clamp(-local_accel.z * body_pitch, -2.0, 2.0))
	roll += feel_noise.get_noise_1d(t + 200.0) * 0.006 * shake
	$Body.transform = Transform3D(Basis.from_euler(Vector3(pitch, 0.0, roll)), offset) * body_rest


func _physics_process(delta: float) -> void:
	var gas = Input.get_action_strength("throttle")
	var brake = Input.get_action_strength("brake")
	var steer_input = Input.get_axis("turn_right", "turn_left")
	var handbrake = Input.is_action_pressed("handbrake")

	var speed = linear_velocity.length()
	var forward = global_transform.basis.z
	var forward_speed = linear_velocity.dot(forward)

	var flat_forward = forward
	flat_forward.y = 0.0
	flat_forward = flat_forward.normalized()
	var flat_vel = linear_velocity
	flat_vel.y = 0.0
	var moving_forward = flat_vel.length() > 5.0 and flat_vel.normalized().dot(flat_forward) > 0.0
	var slip = 0.0
	if moving_forward:
		slip = flat_forward.signed_angle_to(flat_vel.normalized(), Vector3.UP)
	var slip_deg = abs(rad_to_deg(slip))

	feel_time += delta
	update_ground_state()
	update_feel_acceleration(delta)

	# Air drag, and downforce that keeps the car planted at speed.
	apply_central_force(-linear_velocity * speed * air_drag)
	if grounded_wheels > 0:
		apply_central_force(-global_transform.basis.y * downforce * speed * speed)
	else:
		level_in_air(delta)

	# Touching a wall or another car: keep the hit from spinning the car round.
	if get_contact_count() > 0:
		angular_velocity -= Vector3.UP * angular_velocity.dot(Vector3.UP) * clamp(wall_spin_damping * delta, 0.0, 1.0)

	# --- What the pedals mean right now -------------------------------------
	burnout = gas > 0.5 and brake > 0.5 and speed < burnout_max_speed
	var drive = 0.0      # -1 to 1, the push from the engine
	var braking = 0.0    # 0 to 1, the foot brake
	if burnout:
		apply_central_force(-flat_vel * mass * 5.0)
	elif brake > 0.0 and gas > 0.0:
		braking = brake    # both pedals while moving: slow down, then it becomes a burnout
	elif brake > 0.0:
		if forward_speed > 1.0:
			braking = brake
			reverse_timer = 0.0
		else:
			# Stopped with the brake held: after a short pause, reverse.
			reverse_timer += delta
			if reverse_timer > 0.25:
				drive = -brake
			else:
				braking = brake
	else:
		reverse_timer = 0.0
		if gas > 0.0:
			if forward_speed < -1.0:
				braking = gas      # rolling backwards: stop first
			else:
				drive = gas
	throttle = drive
	# Brake lights: on whenever the brake pedal is slowing or holding the car
	# (including a burnout), off once holding it has turned into reversing.
	brake_lights_on = braking > 0.0 or burnout

	# --- Drifting -------------------------------------------------------------
	update_drift(delta, steer_input, handbrake, speed, slip, slip_deg, drive, moving_forward, flat_vel)

	# --- Steering -------------------------------------------------------------
	var steer_limit = max_steer_angle * lerp(1.0, high_speed_steer, clamp(speed / 40.0, 0.0, 1.0))
	var top_speed = max_speed_kmh / 3.6
	if speed > 40.0 and top_speed > 40.0:
		steer_limit = max_steer_angle * lerp(high_speed_steer, top_speed_steer, clamp((speed - 40.0) / (top_speed - 40.0), 0.0, 1.0))
	var counter = 0.0
	if moving_forward:
		counter = clamp(slip * counter_steer_assist, -max_steer_angle, max_steer_angle) * (1.0 - abs(steer_input))
	var target_steer = steer_input * steer_limit + counter
	var steer_rate = steer_speed * lerp(1.0, high_speed_steer_rate, clamp(speed / top_speed, 0.0, 1.0))
	steer_angle = move_toward(steer_angle, target_steer, steer_rate * delta)

	# At speed, damp the car's rotation a little so it feels planted rather than twitchy.
	if not drifting and grounded_wheels > 0:
		var calm = high_speed_stability * clamp(speed / top_speed, 0.0, 1.0)
		angular_velocity -= Vector3.UP * angular_velocity.dot(Vector3.UP) * clamp(calm * delta, 0.0, 1.0)

	# --- Engine and gears -----------------------------------------------------
	var push = update_engine(delta, drive, forward_speed)

	# Launch wheelspin: purely for the wheels and smoke to show.
	var launching = drive > 0.8 and forward_speed < 9.0 and not burnout
	launch_spin = move_toward(launch_spin, clamp(1.0 - (forward_speed - 4.0) / 5.0, 0.0, 1.0) if launching else 0.0, 4.0 * delta)

	# With no pedals the car slows gently, and holds itself still on hills.
	var holding = gas <= 0.0 and brake <= 0.0 and not handbrake and abs(forward_speed) < 1.5
	if gas <= 0.0 and brake <= 0.0 and grounded_wheels > 0 and abs(forward_speed) >= 1.5:
		apply_central_force(-flat_forward * sign(forward_speed) * rolling_drag * mass)

	# --- Wheels ---------------------------------------------------------------
	for wheel in wheels:
		wheel.force_raycast_update()
		if not wheel.is_colliding():
			wheel_load[wheel] = 0.0
			last_compression.erase(wheel)
			continue
		wheel_load[wheel] = apply_suspension(wheel, delta)
		apply_grip(wheel, delta)
		apply_drive(wheel, push)
		apply_brakes(wheel, delta, braking, handbrake, holding)


# ------------------------------------------------------------------------------
# Drift: started with the handbrake, then steered and held on the throttle.
# Steering into it gives more angle, centring gives less, and steering hard the
# other way flicks the car into a drift on the other side.
func update_drift(delta, steer_input, handbrake, speed, slip, slip_deg, drive, moving_forward, flat_vel) -> void:
	if not drifting and handbrake and abs(steer_input) > 0.5 and speed > 12.0 and moving_forward:
		drifting = true
		drift_dir = sign(steer_input)
		neutral_timer = 0.0
		counter_timer = 0.0
		angular_velocity += Vector3.UP * handbrake_kick * drift_dir

	var angle_target = max_drift_angle
	if drifting:
		var steer_into = steer_input * drift_dir   # 1 = steering into the drift, -1 = against it
		angle_target = max_drift_angle * lerp(neutral_drift_angle, 1.0, clamp(steer_into, 0.0, 1.0))

		# Steering held hard the other way: flick to the other side.
		if steer_into < -0.5:
			counter_timer += delta
			if counter_timer > 0.12:
				drift_dir = -drift_dir
				counter_timer = 0.0
				angular_velocity += Vector3.UP * transition_kick * drift_dir
		else:
			counter_timer = 0.0

		# Steering let go for a moment: the drift ends.
		if abs(steer_input) < 0.1:
			neutral_timer += delta
		else:
			neutral_timer = 0.0
		if neutral_timer > 0.15 or speed < 8.0:
			drifting = false

	# Rear grip: lower in a drift, lower still with the handbrake, and it
	# shudders under power as the tyres fight for grip.
	var throttle_amount = 0.5 + 0.5 * max(drive, 0.0)
	var target_factor = 1.0
	if drifting:
		target_factor = 1.0 - drift_grip_loss * throttle_amount
		target_factor += feel_noise.get_noise_1d(feel_time * grip_fight_speed) * grip_fight * throttle_amount
	if handbrake:
		target_factor = min(target_factor, handbrake_grip)
	rear_grip_factor = move_toward(rear_grip_factor, target_factor, grip_change_speed * delta)

	# Past the angle target: damp any rotation that makes the slide bigger, and
	# hand some grip back. This is what stops a spin.
	if slip_deg > angle_target:
		var excess = (slip_deg - angle_target) / 20.0
		var yaw = angular_velocity.dot(Vector3.UP)
		if yaw * slip < 0.0:
			angular_velocity -= Vector3.UP * yaw * clamp(excess * angle_limit_strength * delta, 0.0, 1.0)
		rear_grip_factor = move_toward(rear_grip_factor, 1.0, excess * 4.0 * delta)

	if drifting and moving_forward and drive > 0.0:
		apply_central_force(flat_vel.normalized() * drift_push * drive * clamp(slip_deg / 30.0, 0.0, 1.0))
		# The throttle swings the rear towards the drift's side, fading out near the target angle.
		var progress = -rad_to_deg(slip) * drift_dir   # degrees of slide in the drift's direction
		var room = clamp(1.0 - progress / angle_target, 0.0, 1.5)
		angular_velocity += Vector3.UP * drift_dir * drift_power_yaw * drive * room * delta

	var target_intensity = 0.0
	if drifting:
		target_intensity = clamp(slip_deg / max_drift_angle, 0.0, 1.0) * (0.4 + 0.6 * max(drive, 0.0))
	drift_intensity = move_toward(drift_intensity, target_intensity, 3.0 * delta)


# ------------------------------------------------------------------------------
# Engine: gears spread the top speed out, each gear pulls hardest in its upper
# half, and a gear change cuts the power for a moment. Returns the push in newtons.
func update_engine(delta: float, drive: float, forward_speed: float) -> float:
	var top_speed = max_speed_kmh / 3.6

	if drive < 0.0:
		gear = -1
		var reverse_top = reverse_speed_kmh / 3.6
		rpm = clamp(-forward_speed / reverse_top, 0.0, 1.0)
		on_limiter = false
		if -forward_speed >= reverse_top:
			return 0.0
		return drive * engine_force * 0.6

	if gear < 1:
		gear = 1
	var speed = max(forward_speed, 0.0)
	# Change up near the top of a gear, change down when the revs fall low.
	if speed >= gear_top_speed(gear, top_speed) * 0.97 and gear < gear_count:
		gear += 1
		shift_timer = shift_time
	elif gear > 1 and speed < gear_top_speed(gear - 1, top_speed) * 0.7:
		gear -= 1
	shift_timer = max(shift_timer - delta, 0.0)

	rpm = clamp(speed / gear_top_speed(gear, top_speed), 0.0, 1.0)
	on_limiter = burnout or (drifting and drive > 0.5) or (gear == gear_count and rpm >= 0.995 and drive > 0.0)
	if burnout or (drifting and drive > 0.5):
		# Wheels spinning free: the engine bounces off the limiter.
		rpm = 0.94 + 0.06 * abs(sin(feel_time * 40.0))

	if drive <= 0.0 or shift_timer > 0.0 or speed >= top_speed:
		return 0.0
	# Pulls a little softer low in the gear and right at the limiter.
	var pull = lerp(0.85, 1.0, smoothstep(0.3, 0.75, rpm))
	if rpm > 0.75:
		pull = lerp(1.0, 0.88, (rpm - 0.75) / 0.25)
	return drive * engine_force * pull


func gear_top_speed(g: int, top_speed: float) -> float:
	return top_speed * pow(float(g) / float(gear_count), 0.85)


# ------------------------------------------------------------------------------
func update_ground_state() -> void:
	grounded_wheels = 0
	for wheel in wheels:
		if wheel.is_colliding():
			grounded_wheels += 1


# Smoothed acceleration in the car's own directions, used for the body lean.
func update_feel_acceleration(delta: float) -> void:
	var accel = (linear_velocity - last_velocity) / delta
	last_velocity = linear_velocity
	var local = global_transform.basis.inverse() * accel
	local_accel = local_accel.lerp(local, 1.0 - exp(-8.0 * delta))


# In the air: stop tumbling and settle level, so the car lands on its wheels.
func level_in_air(delta: float) -> void:
	angular_velocity -= angular_velocity * clamp(2.0 * delta, 0.0, 1.0)
	var tilt_axis = global_transform.basis.y.cross(Vector3.UP)
	angular_velocity += tilt_axis * air_levelling * delta


func apply_suspension(wheel: RayCast3D, delta: float) -> float:
	var up = global_transform.basis.y
	var collision_point = wheel.get_collision_point()
	var distance = (wheel.global_position - collision_point).dot(up)
	var compression = rest_length - distance
	var spring_force = spring_strength * compression
	# Bump stop: a much stiffer spring near the end of the travel, so a hard
	# landing doesn't slam the body into the road.
	if compression > bump_stop_start:
		spring_force += bump_stop_strength * (compression - bump_stop_start)
	var compression_speed = (compression - last_compression.get(wheel, compression)) / delta
	last_compression[wheel] = compression
	var damping_force = spring_damping * compression_speed
	var total_force = max(spring_force + damping_force, 0.0)
	apply_force(up * total_force, collision_point - global_position)
	return total_force


func apply_drive(wheel: RayCast3D, push: float) -> void:
	if push == 0.0:
		return
	var is_front = wheel == $FL or wheel == $FR
	var share = front_drive_ratio if is_front else 1.0 - front_drive_ratio
	if share <= 0.0:
		return
	var collision_point = wheel.get_collision_point()
	var wheel_force = global_transform.basis.z * push * share / 2.0
	apply_force(wheel_force, collision_point - global_position)


# Foot brake on all four wheels, handbrake on the rear two, and a hold when the
# car is standing with no pedals so it doesn't roll away on a hill.
func apply_brakes(wheel: RayCast3D, delta: float, braking: float, handbrake: bool, holding: bool) -> void:
	var is_front = wheel == $FL or wheel == $FR
	var force = 0.0
	if braking > 0.0:
		force += braking * brake_force * (brake_front_bias if is_front else 1.0 - brake_front_bias) / 2.0
	if handbrake and not is_front:
		force += handbrake_force / 2.0
	if holding:
		force += brake_force / 4.0
	if force <= 0.0:
		return

	var collision_point = wheel.get_collision_point()
	var forward = global_transform.basis.z
	var wheel_velocity = linear_velocity + angular_velocity.cross(collision_point - to_global(center_of_mass))
	var rolling_speed = wheel_velocity.dot(forward)
	# Never push harder than it takes to stop this corner of the car this frame,
	# otherwise the brakes would shove the car backwards.
	var stop_force = abs(rolling_speed) * (mass / 4.0) / delta
	force = min(force, stop_force)
	apply_force(-forward * sign(rolling_speed) * force, collision_point - global_position)


# Sideways tyre grip. Grip builds with the slide angle, peaks at peak_slip_angle,
# then falls away gently once the tyre is sliding.
func apply_grip(wheel: RayCast3D, delta: float) -> void:
	var is_front = wheel == $FL or wheel == $FR
	var wheel_basis = global_transform.basis
	if is_front:
		wheel_basis = wheel_basis.rotated(wheel_basis.y, steer_angle)
	var wheel_right = wheel_basis.x
	var wheel_forward = wheel_basis.z
	var collision_point = wheel.get_collision_point()
	var wheel_velocity = linear_velocity + angular_velocity.cross(collision_point - to_global(center_of_mass))
	var lateral_speed = wheel_velocity.dot(wheel_right)
	var rolling_speed = abs(wheel_velocity.dot(wheel_forward))

	# More weight on a tyre gives it more grip, less weight gives less.
	var static_load = mass * 9.81 / 4.0
	var load_ratio = clamp(wheel_load.get(wheel, static_load) / static_load, 0.0, 1.6)
	var mu = front_mu if is_front else rear_mu * rear_grip_factor
	var max_force = mu * static_load * lerp(1.0, load_ratio, load_sensitivity)
	if max_force <= 0.0:
		return

	# At low speed the tyre simply cancels sideways movement (very stiff). At
	# speed it is softer: full grip arrives at the peak slide angle.
	var cancel_stiffness = grip * (mass / 4.0) / delta
	var peak_angle = peak_slip_angle if is_front else rear_peak_slip_angle
	var peak_slide_speed = max(rolling_speed * tan(deg_to_rad(peak_angle)), 0.01)
	var stiffness = min(cancel_stiffness, max_force / peak_slide_speed)
	var demand = -lateral_speed * stiffness / max_force
	var amount = abs(demand)
	var curve = amount
	if amount > 1.3:
		curve = lerp(1.0, slide_ratio, smoothstep(1.3, 3.3, amount))
	elif amount > 0.7:
		curve = amount - (amount - 0.7) * (amount - 0.7) / 1.2   # rounds off smoothly into the peak
	var force = sign(demand) * curve * max_force

	var up = global_transform.basis.y
	var com = to_global(center_of_mass)
	var grip_point = collision_point + up * (com - collision_point).dot(up)
	apply_force(wheel_right * force, grip_point - global_position)
