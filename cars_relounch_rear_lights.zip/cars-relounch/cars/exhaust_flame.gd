extends Node3D

# Exhaust flame: a short burst of fire every time the car changes gear.
# Put this node at the tip of the exhaust, as a child of the car. Each burst
# gets a slightly different size, so no two look the same.

@export var min_size: float = 0.75
@export var max_size: float = 1.35
@export var flame_on_downshift: bool = true
@export var flash_brightness: float = 1.8

@onready var car: RigidBody3D = get_parent()
@onready var flame: GPUParticles3D = $Flame
@onready var flash: OmniLight3D = $Flash

var last_gear: int = 1
var pops: int = 0   # how many flames so far (handy for testing)


func _ready() -> void:
	flame.emitting = false
	flash.light_energy = 0.0


func _physics_process(delta: float) -> void:
	if car.gear != last_gear:
		# Only real gear changes while driving forwards, not going in or out of reverse.
		var driving = car.gear >= 1 and last_gear >= 1
		if driving and (car.gear > last_gear or flame_on_downshift):
			pop()
		last_gear = car.gear
	flash.light_energy = move_toward(flash.light_energy, 0.0, 12.0 * delta)


func pop() -> void:
	var size = randf_range(min_size, max_size)
	flame.scale = Vector3.ONE * size
	flame.restart()
	flame.emitting = true
	flash.light_energy = flash_brightness * size
	pops += 1
