extends Node3D

# The car's lights: headlights (low and high beam), tail lights, brake lights,
# reverse lights and fog lights.
#
#   L  cycles the headlights: off > low beam > high beam > off
#   F  switches the fog lights on and off (front, and the rear fog light)
#
# Brake and reverse lights work by themselves, whether the headlights are on or not.
#
# On many cars only parts of the red rear lens light up. The "Tail light sections"
# settings say which heights of the lens are the brake light and the running
# lights. Anything outside those sections stays dark.
#
# The script finds the lamps on the car model on its own. It looks at every
# surface of the body: red at the back is a tail light, white at the back is a
# reverse light, pale at the front is a headlight, pale and low at the front is
# a fog light. Each lamp gets a glowing material and a real light source.

@export var start_with_lights_on: bool = false

@export_group("Manual lamp materials")
# Normally leave these empty: the lamps are found automatically. If a car's lamps
# are picked up wrongly, list the material names here for that kind of lamp instead.
@export var headlight_materials: Array[String] = []
@export var fog_materials: Array[String] = []
@export var tail_materials: Array[String] = []
@export var reverse_materials: Array[String] = []

@export_group("Tail light sections")
# Heights in metres above the car's centre, as (bottom, top). Leave all three at
# (0, 0) and the whole red lens is used for both the tail lights and brake lights.
@export var brake_section: Vector2 = Vector2.ZERO
@export var running_section: Vector2 = Vector2.ZERO
@export var lower_running_section: Vector2 = Vector2.ZERO   # a second running light, and the rear fog light

@export_group("Lamp glow")
@export var headlight_glow: float = 4.0
@export var high_beam_glow: float = 7.0
@export var fog_glow: float = 3.5
@export var tail_glow: float = 0.9
@export var brake_glow: float = 6.5
@export var reverse_glow: float = 3.0
@export var rear_fog_glow: float = 3.5

@export_group("Light thrown on the road")
@export var low_beam_range: float = 45.0
@export var low_beam_energy: float = 6.0
@export var high_beam_range: float = 110.0
@export var high_beam_energy: float = 10.0
@export var fog_range: float = 18.0
@export var fog_energy: float = 3.0
@export var tail_light_energy: float = 0.4
@export var brake_light_energy: float = 1.4
@export var reverse_light_energy: float = 2.0

const HEAD_COLOUR = Color(1.0, 0.95, 0.84)
const FOG_COLOUR = Color(1.0, 0.93, 0.76)
const TAIL_COLOUR = Color(1.0, 0.04, 0.02)
const REVERSE_COLOUR = Color(1.0, 1.0, 0.94)

@onready var car: RigidBody3D = get_parent()

var beam: int = 0          # 0 = off, 1 = low beam, 2 = high beam
var fog_on: bool = false

# For each kind of lamp: its glowing materials and its light sources.
# "tail" is a whole red lens used for everything. When sections are set, the lens
# is split into "brake", "running" and "running_fog" parts instead.
var materials := {"head": [], "fog": [], "tail": [], "brake": [], "running": [], "running_fog": [], "reverse": []}
var lamps := {"head": [], "fog": [], "tail": [], "reverse": []}
# Current brightness of each kind (0 to 1 and beyond), eased so lamps fade rather than snap.
var level := {"head": 0.0, "high": 0.0, "fog": 0.0, "tail": 0.0, "brake": 0.0, "reverse": 0.0}


func _ready() -> void:
	find_lamps()
	if start_with_lights_on:
		beam = 1


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("lights"):
		beam = (beam + 1) % 3
	if event.is_action_pressed("fog_lights"):
		fog_on = not fog_on


func _process(delta: float) -> void:
	var lights_on = beam > 0
	ease_level("head", 1.0 if lights_on else 0.0, 8.0, delta)
	ease_level("high", 1.0 if beam == 2 else 0.0, 8.0, delta)
	ease_level("fog", 1.0 if fog_on else 0.0, 8.0, delta)
	ease_level("tail", 1.0 if lights_on else 0.0, 8.0, delta)
	ease_level("brake", 1.0 if car.brake_lights_on else 0.0, 25.0 if car.brake_lights_on else 10.0, delta)
	ease_level("reverse", 1.0 if car.gear == -1 else 0.0, 12.0, delta)

	# Lamp surfaces.
	set_glow("head", HEAD_COLOUR, lerp(headlight_glow, high_beam_glow, level["high"]) * level["head"])
	set_glow("fog", FOG_COLOUR, fog_glow * level["fog"])
	set_glow("tail", TAIL_COLOUR, max(tail_glow * level["tail"], brake_glow * level["brake"]))
	set_glow("brake", TAIL_COLOUR, brake_glow * level["brake"])
	set_glow("running", TAIL_COLOUR, tail_glow * level["tail"])
	set_glow("running_fog", TAIL_COLOUR, max(tail_glow * level["tail"], rear_fog_glow * level["fog"]))
	set_glow("reverse", REVERSE_COLOUR, reverse_glow * level["reverse"])

	# Light sources.
	for lamp in lamps["head"]:
		lamp.light_energy = lerp(low_beam_energy, high_beam_energy, level["high"]) * level["head"]
		lamp.spot_range = lerp(low_beam_range, high_beam_range, level["high"])
		lamp.rotation.x = deg_to_rad(lerp(-5.0, -1.0, level["high"]))   # low beam dips, high beam looks ahead
		lamp.visible = lamp.light_energy > 0.01
	for lamp in lamps["fog"]:
		lamp.light_energy = fog_energy * level["fog"]
		lamp.visible = lamp.light_energy > 0.01
	for lamp in lamps["tail"]:
		lamp.light_energy = max(tail_light_energy * level["tail"], brake_light_energy * max(level["brake"], 0.8 * level["fog"]))
		lamp.visible = lamp.light_energy > 0.01
	for lamp in lamps["reverse"]:
		lamp.light_energy = reverse_light_energy * level["reverse"]
		lamp.visible = lamp.light_energy > 0.01


func ease_level(key: String, target: float, rate: float, delta: float) -> void:
	level[key] = move_toward(level[key], target, rate * delta)


func set_glow(kind: String, colour: Color, energy: float) -> void:
	for material in materials[kind]:
		material.emission_enabled = energy > 0.01
		material.emission = colour
		material.emission_energy_multiplier = energy


# ------------------------------------------------------------------------------
# Finding the lamps on the model.

func find_lamps() -> void:
	var body = car.get_node_or_null("Body")
	if body == null:
		return
	var to_car = car.global_transform.affine_inverse()

	# First pass: every surface of the body, with its points in the car's own space.
	var surfaces = read_surfaces(body, to_car)
	var front = -INF
	var back = INF
	for surface in surfaces:
		for point in surface["points"]:
			front = max(front, point.z)
			back = min(back, point.z)

	# If this car's rear lens has sections, cut the lens into those sections so
	# each one can be lit by itself, then read the surfaces again.
	var section_of = {}   # surface -> "brake", "running", "running_fog" or "unused"
	if has_sections():
		for surface in surfaces:
			if lamp_kind(surface, front, back) == "tail":
				var roles = split_lens(surface["instance"], surface["index"], to_car)
				surfaces = read_surfaces(body, to_car)
				for other in surfaces:
					if other["instance"] == surface["instance"] and roles.has(other["index"]):
						section_of[[other["instance"], other["index"]]] = roles[other["index"]]
				break

	# Second pass: decide what each surface is, and make it a lamp.
	for surface in surfaces:
		var kind = lamp_kind(surface, front, back)
		if kind == "":
			continue
		# A piece of a split lens takes the job of its section.
		var key = [surface["instance"], surface["index"]]
		var light_source = kind
		if section_of.has(key):
			kind = section_of[key]
			if kind == "unused":
				continue
			light_source = "tail"

		# Give this car its own copy of the material, so lighting it up doesn't
		# light up every other car that uses the same model.
		var own = surface["material"].duplicate()
		surface["instance"].set_surface_override_material(surface["index"], own)
		materials[kind].append(own)
		add_lamps(light_source, surface["points"])


func read_surfaces(body: Node, to_car: Transform3D) -> Array:
	var surfaces = []
	for mesh_instance in find_meshes(body):
		var lower = mesh_instance.name.to_lower()
		if lower.contains("wheel") or lower.contains("circle"):
			continue
		var mesh = mesh_instance.mesh
		for i in mesh.get_surface_count():
			var material = mesh.surface_get_material(i)
			if not material is BaseMaterial3D:
				continue
			var points = []
			for vertex in mesh.surface_get_arrays(i)[Mesh.ARRAY_VERTEX]:
				points.append(to_car * (mesh_instance.global_transform * vertex))
			surfaces.append({"instance": mesh_instance, "index": i, "material": material, "points": points})
	return surfaces


# What a surface is, from its colour and where it sits on the car:
# "head", "fog", "tail", "reverse", or "" for not a lamp.
func lamp_kind(surface: Dictionary, front: float, back: float) -> String:
	# Manual lists, if any are filled in, decide instead.
	var manual = {"head": headlight_materials, "fog": fog_materials, "tail": tail_materials, "reverse": reverse_materials}
	var any_manual = false
	for key in manual:
		if not manual[key].is_empty():
			any_manual = true
	if any_manual:
		for key in manual:
			if surface["material"].resource_name in manual[key]:
				return key
		return ""

	var centre = Vector3.ZERO
	for point in surface["points"]:
		centre += point
	centre /= surface["points"].size()
	var colour = surface["material"].albedo_color
	var pale = min(colour.r, min(colour.g, colour.b)) > 0.65
	var red = colour.r > 0.15 and colour.r > colour.g * 3.0 and colour.r > colour.b * 3.0
	# Lamps at the front come as a left and right pair with a gap between them.
	# A grille or a badge runs across the middle, so it is not a lamp.
	var nearest_to_middle = INF
	for point in surface["points"]:
		nearest_to_middle = min(nearest_to_middle, abs(point.x))
	var is_pair = nearest_to_middle > 0.12

	if centre.z < back * 0.75:
		if red:
			return "tail"
		if pale:
			return "reverse"
	elif centre.z > front * 0.75 and pale and is_pair:
		return "fog" if centre.y < 0.0 else "head"
	return ""


func has_sections() -> bool:
	return brake_section != Vector2.ZERO or running_section != Vector2.ZERO or lower_running_section != Vector2.ZERO


func section_for_height(height: float) -> String:
	if height >= brake_section.x and height < brake_section.y:
		return "brake"
	if height >= running_section.x and height < running_section.y:
		return "running"
	if height >= lower_running_section.x and height < lower_running_section.y:
		return "running_fog"
	return "unused"


# Cuts one surface of a mesh (the red rear lens) into separate surfaces, one per
# section, by the height of each triangle. The car gets its own copy of the
# mesh, so the model file and other cars are untouched. Returns which section
# each new surface is.
func split_lens(mesh_instance: MeshInstance3D, lens_index: int, to_car: Transform3D) -> Dictionary:
	var old_mesh = mesh_instance.mesh
	var new_mesh = ArrayMesh.new()
	var roles = {}
	for i in old_mesh.get_surface_count():
		var arrays = old_mesh.surface_get_arrays(i)
		if i != lens_index:
			new_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			new_mesh.surface_set_material(new_mesh.get_surface_count() - 1, old_mesh.surface_get_material(i))
			continue

		var vertices = arrays[Mesh.ARRAY_VERTEX]
		var indices = arrays[Mesh.ARRAY_INDEX]
		if indices == null or indices.is_empty():
			indices = PackedInt32Array(range(vertices.size()))
		var triangles = {}   # section -> the triangles in it
		for t in range(0, indices.size(), 3):
			var middle = (vertices[indices[t]] + vertices[indices[t + 1]] + vertices[indices[t + 2]]) / 3.0
			var height = (to_car * (mesh_instance.global_transform * middle)).y
			var section = section_for_height(height)
			if not triangles.has(section):
				triangles[section] = PackedInt32Array()
			triangles[section].append(indices[t])
			triangles[section].append(indices[t + 1])
			triangles[section].append(indices[t + 2])
		for section in triangles:
			var part = arrays.duplicate()
			part[Mesh.ARRAY_INDEX] = triangles[section]
			new_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, part)
			var index = new_mesh.get_surface_count() - 1
			new_mesh.surface_set_material(index, old_mesh.surface_get_material(i))
			roles[index] = section
	mesh_instance.mesh = new_mesh
	return roles


func find_meshes(node: Node) -> Array:
	var found = []
	for child in node.get_children():
		if child is MeshInstance3D:
			found.append(child)
		found.append_array(find_meshes(child))
	return found


# One light source on each side of the car for this kind of lamp, placed in the
# middle of the lamp surface on that side.
func add_lamps(kind: String, points: Array) -> void:
	if not lamps[kind].is_empty():
		return   # this kind already has its pair (headlights can be two surfaces)
	for side in [1.0, -1.0]:
		var centre = Vector3.ZERO
		var count = 0
		for point in points:
			if point.x * side > 0.05:
				centre += point
				count += 1
		if count == 0:
			continue
		centre /= count

		var lamp: Light3D
		if kind == "head" or kind == "fog":
			var spot = SpotLight3D.new()
			spot.spot_angle = 38.0 if kind == "head" else 55.0
			spot.spot_range = low_beam_range if kind == "head" else fog_range
			spot.spot_attenuation = 0.8
			spot.light_color = HEAD_COLOUR if kind == "head" else FOG_COLOUR
			# A spotlight shines along its own -Z, and the car's front is +Z: turn it round.
			spot.rotation = Vector3(deg_to_rad(-5.0 if kind == "head" else -8.0), PI, 0.0)
			spot.position = centre + Vector3(0.0, 0.0, 0.1)
			lamp = spot
		else:
			# Rear lamps shine backwards and down at the road, so they light the
			# ground behind the car without flooding the car's own bodywork.
			var spot = SpotLight3D.new()
			spot.spot_angle = 60.0
			spot.spot_range = 6.0 if kind == "tail" else 9.0
			spot.spot_attenuation = 1.0
			spot.light_color = TAIL_COLOUR if kind == "tail" else REVERSE_COLOUR
			spot.rotation = Vector3(deg_to_rad(-25.0), 0.0, 0.0)
			spot.position = centre + Vector3(0.0, 0.0, -0.15)
			lamp = spot
		lamp.light_energy = 0.0
		lamp.visible = false
		lamp.shadow_enabled = false
		add_child(lamp)
		lamps[kind].append(lamp)
