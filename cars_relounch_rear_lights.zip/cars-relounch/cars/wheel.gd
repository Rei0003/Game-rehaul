extends Node3D

# Visual wheel. It sits where its suspension ray touches the ground,
# turns with the steering (front wheels only) and spins with the car's speed.
# 'steers' also marks it as a front wheel.
# The physics never looks at this node, it's only for looks.
@export var radius: float = 0.31
@export var steers: bool = false
@export var smoke_side_speed: float = 4.0  # m/s of sideways sliding before smoke starts
@export var burnout_spin: float = 45.0  # how fast a driven wheel spins in a burnout (rad/s)
@export var wheelspin_extra: float = 30.0  # extra spin on driven wheels when powering through a drift (rad/s)

@onready var ray: RayCast3D = get_parent()
@onready var car: RigidBody3D = ray.get_parent()
@onready var spin_node: Node3D = $Spin
@onready var smoke: GPUParticles3D = get_node_or_null("Smoke")

func _ready() -> void:
	use_model_wheel()

# Swaps the placeholder cylinders for the wheel modelled in Blender: a mesh inside
# the car body whose name contains "Wheel" or "Circle". Only one wheel needs to be
# modelled, every corner gets a copy, and the copies on the other side are turned round.
func use_model_wheel() -> void:
	var body = car.get_node_or_null("Body")
	if body == null:
		return
	var source = find_wheel_mesh(body)
	if source == null:
		return
	source.visible = false
	for child in spin_node.get_children():
		child.queue_free()

	var mesh_center = source.mesh.get_aabb().get_center()
	var wheel_basis = car.global_transform.basis.inverse() * source.global_transform.basis
	var source_side = sign(car.to_local(source.global_transform * mesh_center).x)
	if sign(ray.position.x) != source_side:
		wheel_basis = Basis(Vector3.UP, PI) * wheel_basis

	var copy = MeshInstance3D.new()
	copy.mesh = source.mesh
	copy.transform = Transform3D(wheel_basis, -(wheel_basis * mesh_center))
	spin_node.add_child(copy)

func find_wheel_mesh(node: Node) -> MeshInstance3D:
	for child in node.get_children():
		var lower = child.name.to_lower()
		if child is MeshInstance3D and (lower.contains("wheel") or lower.contains("circle")):
			return child
		var found = find_wheel_mesh(child)
		if found:
			return found
	return null

func _physics_process(delta: float) -> void:
	var travel = car.rest_length
	if ray.is_colliding():
		travel = (ray.global_position - ray.get_collision_point()).dot(car.global_transform.basis.y)
	position.y = -(travel - radius)

	if steers:
		rotation.y = car.steer_angle

	var is_driven = (steers and car.front_drive_ratio > 0.0) or (not steers and car.front_drive_ratio < 1.0)
	var burning = car.burnout and is_driven

	var spin_speed = car.linear_velocity.dot(car.global_transform.basis.z) / radius
	# Powering through a drift, or launching hard: the driven wheels spin faster than the road.
	var wheelspin = is_driven and ((car.drifting and car.throttle > 0.5) or car.launch_spin > 0.3)
	if burning:
		spin_speed = burnout_spin
	elif wheelspin:
		spin_speed = spin_speed * 1.3 + wheelspin_extra * car.throttle
	spin_node.rotation.x = wrapf(spin_node.rotation.x + spin_speed * delta, 0.0, TAU)

	# Tyre smoke: when the tyre slides sideways, when the handbrake locks a rear
	# wheel at speed, when a driven wheel is doing a burnout, or spinning in a power drift.
	if smoke:
		var on_ground = ray.is_colliding()
		var wheel_velocity = car.linear_velocity + car.angular_velocity.cross(global_position - car.global_position)
		var side_speed = abs(wheel_velocity.dot(car.global_transform.basis.x))
		var locked = not steers and Input.is_action_pressed("handbrake") and car.linear_velocity.length() > 5.0
		smoke.emitting = on_ground and (side_speed > smoke_side_speed or locked or burning or wheelspin)
