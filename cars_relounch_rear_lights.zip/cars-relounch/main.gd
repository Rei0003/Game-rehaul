extends Node3D

# Puts the car (and camera) at the stage's Start marker when the game begins.
# The car drives along the marker's blue (Z) axis.
@onready var car: RigidBody3D = $Scene/Car
@onready var start: Marker3D = $Stage1/Start
@onready var camera: Camera3D = $Camera3D

func _ready() -> void:
	car.global_transform = start.global_transform
	car.global_position += Vector3.UP * 1.0
	camera.reset_view()
