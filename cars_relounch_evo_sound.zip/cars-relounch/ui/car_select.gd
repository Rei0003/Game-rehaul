extends CanvasLayer

# Car select screen, shown when the game starts.
#
#   Left / Right (or A / D)   change car
#   Enter or Space            drive
#
# The arrows and the Drive button work with the mouse too. The screen only
# shows the choice: main.gd puts the highlighted car on the start line and
# starts the drive when one is picked.

signal highlighted(index: int)
signal chosen(index: int)

var cars: Array = []   # one dictionary per car: name, drive, engine (set by main.gd)
var index: int = 0

@onready var car_name: Label = %CarName
@onready var details: Label = %Details
@onready var counter: Label = %Counter
@onready var previous_button: Button = %Previous
@onready var next_button: Button = %Next
@onready var drive_button: Button = %Drive


func _ready() -> void:
	previous_button.pressed.connect(step.bind(-1))
	next_button.pressed.connect(step.bind(1))
	drive_button.pressed.connect(confirm)


func open(car_list: Array, start_index: int = 0) -> void:
	cars = car_list
	index = clampi(start_index, 0, cars.size() - 1)
	visible = true
	show_car()


func step(direction: int) -> void:
	index = wrapi(index + direction, 0, cars.size())
	show_car()


func show_car() -> void:
	var car = cars[index]
	car_name.text = car["name"]
	details.text = "%s   ·   %s" % [car["drive"], car["engine"]]
	counter.text = "%d / %d" % [index + 1, cars.size()]
	highlighted.emit(index)


func confirm() -> void:
	visible = false
	chosen.emit(index)


func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	if event.is_action_pressed("ui_left") or event.is_action_pressed("turn_left"):
		step(-1)
	elif event.is_action_pressed("ui_right") or event.is_action_pressed("turn_right"):
		step(1)
	elif event.is_action_pressed("ui_accept"):
		confirm()
	else:
		return
	get_viewport().set_input_as_handled()
