extends Node3D

# Starts the game with the car select screen. The highlighted car waits on the
# stage's Start marker while the camera circles it; once a car is picked, the
# camera goes behind it and the controls come on.
# Cars drive along the marker's blue (Z) axis.
#
# To add a car: make its scene (a root node with the RigidBody3D named "Car"
# inside, like Car.tscn) and add a line to CARS.

const CARS = [
	{"name": "Volvo 850 R", "scene": "res://Car.tscn", "drive": "Front-wheel drive", "engine": "2.3 L turbo five"},
	{"name": "Mitsubishi Lancer Evolution III", "scene": "res://cars/evo3/Evo3.tscn", "drive": "All-wheel drive", "engine": "2.0 L turbo four"},
]

@onready var start: Marker3D = $Stage1/Start
@onready var camera: Camera3D = $Camera3D
@onready var car_select = $CarSelect

var car_scene: Node3D   # the whole scene of the car on the start line
var car: RigidBody3D    # its RigidBody3D


func _ready() -> void:
	car_select.highlighted.connect(place_car)
	car_select.chosen.connect(drive)
	camera.showroom = true
	car_select.open(CARS, 0)


# Puts this car on the start line, in place of the one there before.
func place_car(index: int) -> void:
	if car_scene:
		car_scene.queue_free()
	car_scene = load(CARS[index]["scene"]).instantiate()
	add_child(car_scene)
	car = car_scene.get_node("Car")
	car.controls_enabled = false
	car.global_transform = start.global_transform
	car.global_position += Vector3.UP * 0.6
	camera.follow(car)


func drive(_index: int) -> void:
	car.controls_enabled = true
	camera.showroom = false
	camera.reset_view()
