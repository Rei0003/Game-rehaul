Volvo 850 R — 2.3 20v turbo I5 : engine loops from Engine Loop Studio
==========================================================

Files
  850r_on_XXXXX.wav   on-throttle (full load) loop at XXXXX rpm
  850r_off_XXXXX.wav  off-throttle / decel loop at XXXXX rpm
  RPM points: 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500, 7000
  44100 Hz, 16-bit mono, 2 s per loop (an exact number of engine cycles).
  Every file holds a 'smpl' loop chunk covering the whole file.
  Levels are normalized across the whole set, so loudness vs rpm is preserved.

Godot 4
  1. Copy this folder to res://audio/engine/850r/
  2. Add a Node3D to your car, attach engine_sound.gd.
  3. Every frame from your car script:
       $EngineSound.rpm = engine_rpm
       $EngineSound.throttle = throttle_input   # 0..1
  The script plays every loop at once (silent ones muted), crossfades the two
  loops nearest the current rpm with equal-power curves, sets pitch_scale =
  rpm / loop_rpm, and blends the on/off sets by throttle.
  Import settings: keep Loop Mode on "Detect From WAV" (reads the loop points
  stored in each file). For perfectly exact loops set Compress Mode to
  "Disabled" (plain 16-bit PCM). The script also turns looping on itself if an
  import setting switched it off.

Other engines (Unity, FMOD, Wwise, Unreal) use the same idea: one looping
voice per file, pitch = currentRpm / fileRpm, crossfade neighbours.
