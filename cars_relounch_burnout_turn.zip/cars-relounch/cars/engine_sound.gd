extends Node3D

# Engine sound for a car, made from a set of looping recordings at fixed revs.
# Put this node inside the car and point sample_folder at a folder of loops named
#   <name>_on_<rpm>.wav    on the throttle
#   <name>_off_<rpm>.wav   off the throttle (optional)
# for example 850r_on_03000.wav. The script finds the loops by itself, so a
# different car only needs a different folder.
#
# How it works: the two loops nearest the current revs play together, each
# pitched to match the revs exactly, and they fade into one another as the revs
# move. The on and off sets are mixed by how hard the engine is working.
#
# The revs come from the car script: its gears, wheelspin off the line, the
# limiter in a burnout or drift, and the short power cut on each gear change.

@export_dir var sample_folder: String = "res://audio/engine/850r"
@export var volume_db: float = -10.0     # leaves headroom: several loops play at once
@export var bus: StringName = &"Master"

@export_group("Revs")
@export var idle_rpm: float = 900.0
@export var redline_rpm: float = 6800.0   # the top of each gear
@export var launch_rpm: float = 5200.0    # revs while the wheels spin off the line
@export var launch_ends_kmh: float = 50.0 # by this speed the tyres have bitten and the revs follow the road
@export var rev_up_speed: float = 12000.0   # how fast the revs can rise (rpm per second)
@export var rev_down_speed: float = 8000.0  # how fast they can fall
@export var load_speed: float = 25.0        # how fast the sound moves between on and off throttle

@export_group("Limiter")
@export_range(0.0, 1.0) var limiter_cut: float = 0.25   # power left in each limiter cut (lower = harsher stutter)

@export_group("Distance")
@export var full_volume_distance: float = 12.0   # closer than this the engine is at full volume

@onready var car: RigidBody3D = get_parent()

# Read these from other scripts, for example a rev counter.
var rpm: float = 0.0           # the revs you hear right now
var engine_load: float = 0.0   # 0 = off the throttle, 1 = full throttle
var launch: float = 0.0        # 0 to 1, how much the launch flare is in play

var rpm_points: Array[int] = []                 # the revs each loop was recorded at
var on_players: Array[AudioStreamPlayer3D] = []
var off_players: Array[AudioStreamPlayer3D] = []


func _ready() -> void:
	rpm = idle_rpm
	find_loops()


# Looks through the folder for loops and makes one player for each.
func find_loops() -> void:
	var folder = sample_folder.trim_suffix("/")
	var loop_name = ""
	for file in ResourceLoader.list_directory(folder):
		var marker = file.find("_on_")
		if marker < 0 or not file.ends_with(".wav"):
			continue
		loop_name = file.substr(0, marker)
		rpm_points.append(int(file.substr(marker + 4)))
	rpm_points.sort()
	if rpm_points.is_empty():
		push_warning("EngineSound: no loops named <name>_on_<rpm>.wav found in " + folder)
		return

	for point in rpm_points:
		var on_player = make_player("%s/%s_on_%05d.wav" % [folder, loop_name, point])
		if on_player == null:
			# A loop would not load (not imported yet?): stay silent rather than break.
			push_warning("EngineSound: could not load the loops in " + folder)
			for player in on_players + off_players:
				player.queue_free()
			on_players.clear()
			off_players.clear()
			rpm_points.clear()
			return
		on_players.append(on_player)
		var off_path = "%s/%s_off_%05d.wav" % [folder, loop_name, point]
		if ResourceLoader.exists(off_path):
			var off_player = make_player(off_path)
			if off_player != null:
				off_players.append(off_player)
	# The off-throttle set is only used if it is complete.
	if off_players.size() != on_players.size():
		for player in off_players:
			player.queue_free()
		off_players.clear()


func make_player(path: String) -> AudioStreamPlayer3D:
	var stream = load(path) as AudioStreamWAV
	if stream == null:
		return null
	# The loops carry their own loop points. If the import settings switched
	# looping off, loop the whole file anyway.
	if stream.loop_mode == AudioStreamWAV.LOOP_DISABLED:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		stream.loop_begin = 0
		stream.loop_end = int(round(stream.get_length() * stream.mix_rate))
	var player = AudioStreamPlayer3D.new()
	player.stream = stream
	player.bus = bus
	player.volume_db = -80.0
	player.max_db = 0.0
	player.unit_size = full_volume_distance
	player.attenuation_filter_cutoff_hz = 20500.0   # no muffling with distance
	add_child(player)
	player.play()
	player.stream_paused = true
	return player


func _process(delta: float) -> void:
	if rpm_points.is_empty():
		return
	update_revs(delta)
	update_players()


# Works out the revs and the engine load from what the car is doing.
func update_revs(delta: float) -> void:
	# car.rpm runs from 0 to 1 through each gear, so the revs climb, drop on a
	# gear change and climb again. The engine never falls below idle.
	var road_rpm = max(idle_rpm, car.rpm * redline_rpm)
	var target = road_rpm
	# Pulling away hard in first gear: the wheels spin, so the revs flare up before
	# the car has speed, then ease onto the road speed as the tyres bite.
	var pulling_away = car.gear == 1 and car.throttle > 0.8 and not car.burnout
	launch = move_toward(launch, 1.0 if pulling_away else 0.0, 5.0 * delta)
	if launch > 0.0:
		var forward_speed = car.linear_velocity.dot(car.global_transform.basis.z)
		var bite = smoothstep(4.0, launch_ends_kmh / 3.6, forward_speed)
		var flare = lerp(launch_rpm, road_rpm, bite)
		target = max(road_rpm, lerp(road_rpm, flare, launch))
	var rate = rev_up_speed if target > rpm else rev_down_speed
	rpm = move_toward(rpm, target, rate * delta)

	var on_limiter = car.burnout or (car.drifting and car.throttle > 0.5)
	var wanted = clamp(abs(car.throttle), 0.0, 1.0)
	if car.burnout:
		wanted = 1.0
	if car.shift_timer > 0.0:
		wanted = 0.0   # the power cut on a gear change
	if on_limiter and car.rpm > 0.985:
		wanted = limiter_cut   # bouncing off the limiter: the engine cuts at the top of each bounce
	engine_load = lerp(engine_load, wanted, 1.0 - exp(-load_speed * delta))


# Sets the volume and pitch of every loop for the current revs and load.
func update_players() -> void:
	var count = rpm_points.size()
	# The pair of loops the revs sit between, and how far along from one to the other.
	var lower = 0
	while lower < count - 2 and rpm > rpm_points[lower + 1]:
		lower += 1
	var along = 0.0
	if count > 1:
		along = clamp((rpm - rpm_points[lower]) / float(rpm_points[lower + 1] - rpm_points[lower]), 0.0, 1.0)

	var has_off = not off_players.is_empty()
	var on_gain = sin(engine_load * PI * 0.5) if has_off else 1.0
	var off_gain = cos(engine_load * PI * 0.5) if has_off else 0.0
	for i in count:
		var gain = 0.0
		if i == lower:
			gain = cos(along * PI * 0.5)
		elif i == lower + 1:
			gain = sin(along * PI * 0.5)
		var pitch = clamp(rpm / float(rpm_points[i]), 0.05, 4.0)
		set_player(on_players[i], gain * on_gain, pitch)
		if has_off:
			set_player(off_players[i], gain * off_gain, pitch)


func set_player(player: AudioStreamPlayer3D, gain: float, pitch: float) -> void:
	if gain < 0.001:
		player.volume_db = -80.0
		player.stream_paused = true   # silent loops don't cost anything
		return
	player.stream_paused = false
	player.volume_db = linear_to_db(gain) + volume_db
	player.pitch_scale = pitch
