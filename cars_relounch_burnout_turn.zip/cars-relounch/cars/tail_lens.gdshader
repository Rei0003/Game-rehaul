shader_type spatial;

// Rear lamp lens where only some rectangular blocks light up, as on cars whose
// tail lamp is one big red lens with separate bulbs behind it.
// The lights script fills in the values. Positions are in the car's own space:
// x = distance from the car's centre line, y = height above the car's centre.

uniform vec4 albedo : source_color = vec4(0.5, 0.02, 0.02, 1.0);
uniform float roughness = 0.2;
uniform float metallic = 0.0;
uniform float specular = 0.5;
uniform vec3 glow_colour : source_color = vec3(1.0, 0.04, 0.02);
uniform mat4 mesh_to_car;

// Each block: x = inner edge (nearest the middle of the car), y = bottom, z = top.
uniform vec3 brake_block = vec3(0.0);
uniform vec3 running_block = vec3(0.0);
uniform vec3 lower_block = vec3(0.0);
uniform float brake_glow = 0.0;
uniform float running_glow = 0.0;
uniform float lower_glow = 0.0;

varying vec3 car_pos;

void vertex() {
	car_pos = (mesh_to_car * vec4(VERTEX, 1.0)).xyz;
}

// 1 inside the block, 0 outside, with a 2 mm soft edge so it doesn't look jagged.
float inside(vec3 block) {
	float edge = 0.002;
	float from_inner = smoothstep(block.x - edge, block.x + edge, abs(car_pos.x));
	float above_bottom = smoothstep(block.y - edge, block.y + edge, car_pos.y);
	float below_top = 1.0 - smoothstep(block.z - edge, block.z + edge, car_pos.y);
	return from_inner * above_bottom * below_top;
}

void fragment() {
	ALBEDO = albedo.rgb;
	ROUGHNESS = roughness;
	METALLIC = metallic;
	SPECULAR = specular;
	float glow = inside(brake_block) * brake_glow + inside(running_block) * running_glow + inside(lower_block) * lower_glow;
	EMISSION = glow_colour * glow;
}
