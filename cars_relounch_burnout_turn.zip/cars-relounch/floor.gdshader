shader_type spatial;
varying vec3 world_pos;

void vertex() {
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 coord = world_pos.xz / 4.0;
	vec2 grid = abs(fract(coord - 0.5) - 0.5) / fwidth(coord);
	float line = min(grid.x, grid.y);
	ALBEDO = vec3(mix(0.05, 0.7, clamp(line, 0.0, 1.0)));
	ROUGHNESS = 1.0;
}
