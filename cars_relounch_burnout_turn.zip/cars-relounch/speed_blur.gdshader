shader_type canvas_item;

// Speed blur: streaks the picture outwards from the point the car is heading
// towards, like the Need for Speed games. The area around the car stays sharp.
// The camera script sets these values every frame.

uniform sampler2D screen_texture : hint_screen_texture, filter_linear, repeat_disable;
uniform float strength = 0.0;                 // 0 = off, 1 = full
uniform vec2 heading_point = vec2(0.5, 0.5);  // where on screen the car is heading
uniform vec2 sharp_point = vec2(0.5, 0.6);    // where on screen the car is
uniform float sharp_radius = 0.3;             // size of the sharp area (share of screen height)
uniform float max_blur = 0.14;                // streak length at the screen edge

const int SAMPLES = 12;

void fragment() {
	vec2 uv = SCREEN_UV;
	vec2 away = uv - heading_point;

	// Distance from the car on screen, corrected so the sharp area is round.
	float aspect = SCREEN_PIXEL_SIZE.y / SCREEN_PIXEL_SIZE.x;
	float from_car = length((uv - sharp_point) * vec2(aspect, 1.0));
	float amount = strength * max_blur * smoothstep(sharp_radius, sharp_radius + 0.5, from_car);

	vec3 colour = vec3(0.0);
	for (int i = 0; i < SAMPLES; i++) {
		float step = float(i) / float(SAMPLES - 1);
		colour += texture(screen_texture, uv - away * amount * step).rgb;
	}
	COLOR = vec4(colour / float(SAMPLES), 1.0);
}
