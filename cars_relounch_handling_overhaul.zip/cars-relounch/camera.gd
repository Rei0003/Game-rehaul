extends Camera3D

@export var target: Node3D
@export var distance: float = 4.0
@export var height: float = 1.4
@export var follow_speed: float = 5.0

# Burnout view: the camera swings round to look at the driven wheels.
@export var burnout_distance: float = 3.2
@export var burnout_height: float = 0.7
@export var burnout_blend_in: float = 1.2   # how fast it swings round (1 / seconds)
@export var burnout_blend_out: float = 1.8  # how fast it swings back after the burnout
@export var burnout_fov: float = 55.0  # narrower view = zoomed in on the wheels

# Shake and a slightly wider view when the car is working hard in a drift or burnout.
@export var drift_shake: float = 0.04    # metres
@export var drift_fov_boost: float = 4.0  # degrees

var cam_dir: Vector3 = Vector3.BACK
var offset: Vector3 = Vector3.ZERO  # camera position relative to the car
var burnout_blend: float = 0.0  # 0 = normal chase view, 1 = burnout view
var shake_noise := FastNoiseLite.new()
var shake_time: float = 0.0

func _physics_process(delta: float) -> void:
	var body = target as RigidBody3D
	var heading = target.global_transform.basis.z
	heading.y = 0.0
	heading = heading.normalized()

	var vel = body.linear_velocity
	vel.y = 0.0
	var speed = vel.length()

	var desired = heading
	if speed > 5.0 and vel.normalized().dot(heading) > 0.0:
		desired = heading.slerp(vel.normalized(), 0.7)

	cam_dir = cam_dir.slerp(desired, 1.0 - exp(-3.0 * delta)).normalized()

	# Smooth the offset from the car, not the world position. Smoothing the world
	# position made the camera fall further behind the faster the car went.
	# Burnout view. It orbits round instead of sliding straight across,
	# so it never passes through the car on the way.
	var burning = body.burnout
	var blend_rate = burnout_blend_in if burning else burnout_blend_out
	burnout_blend = move_toward(burnout_blend, 1.0 if burning else 0.0, blend_rate * delta)
	var b = smoothstep(0.0, 1.0, burnout_blend)

	# Which axle to look at: front for FWD, rear for RWD, the middle for AWD.
	var axle_z = lerp(-1.35, 1.35, body.front_drive_ratio)
	# How far round the car to swing: front 3/4 view for FWD, rear 3/4 for RWD.
	var orbit_angle = deg_to_rad(lerp(55.0, 135.0, body.front_drive_ratio)) * b
	var orbit_dir = (-cam_dir).rotated(Vector3.UP, -orbit_angle)
	var focus = heading * axle_z * b

	# The sin() term swings the camera wider halfway round, so it keeps clear of the car's side.
	var orbit_distance = lerp(distance, burnout_distance, b) + sin(b * PI) * 1.5
	var wanted_offset = focus + orbit_dir * orbit_distance + Vector3.UP * lerp(height, burnout_height, b)
	if offset == Vector3.ZERO:
		offset = wanted_offset
	offset = offset.lerp(wanted_offset, 1.0 - exp(-follow_speed * delta))
	shake_time += delta
	var intensity = max(body.drift_intensity, b)
	var shake = Vector3(shake_noise.get_noise_1d(shake_time * 30.0), shake_noise.get_noise_1d(shake_time * 30.0 + 50.0), 0.0) * drift_shake * intensity
	global_position = target.global_position + offset + global_transform.basis * shake
	look_at(target.global_position + focus + Vector3.UP * lerp(0.7, 0.1, b), Vector3.UP)
	fov = lerp(lerp(70.0, 76.0, clamp(speed / 60.0, 0.0, 1.0)) + drift_fov_boost * body.drift_intensity, burnout_fov, b)
